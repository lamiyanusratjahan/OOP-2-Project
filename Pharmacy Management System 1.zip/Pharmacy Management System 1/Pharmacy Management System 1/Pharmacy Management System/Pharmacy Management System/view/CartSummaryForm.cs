﻿using Pharmacy_Management_System.controller;
using Pharmacy_Management_System.model;
using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace Pharmacy_Management_System.view
{
    public partial class CartSummaryForm : Form
    {
        public CartSummaryForm()
        {
            InitializeComponent();
        }

        // List to hold cart items
        private List<CartItem> cartItems = new List<CartItem>();

        // Method to display cart items in the DataGridView
        public void Display()
        {
            // Display cart items in DataGridView
            Cart.DisplayAndSearch("SELECT cartSerial, productName, priceAfterDiscount, quantity, total FROM cartTable", dataGridView);

            // Calculate total amount
            double totalAmount = 0;

            // Loop through the rows in DataGridView to calculate total
            foreach (DataGridViewRow row in dataGridView.Rows)
            {
                // Check if priceAfterDiscount and quantity cells are not null
                if (row.Cells["priceAfterDiscount"].Value != null && row.Cells["quantity"].Value != null)
                {
                    // Get price and quantity values from the DataGridView
                    double price = Convert.ToDouble(row.Cells["priceAfterDiscount"].Value);
                    int quantity = Convert.ToInt32(row.Cells["quantity"].Value);

                    // Calculate total for this row and add it to the totalAmount
                    totalAmount += price * quantity;
                }
            }

            // Update the textBoxTotalAmount with the calculated total amount
            textBoxTotalAmount.Text = totalAmount.ToString("C2");  // Format as currency (e.g., $12.34)
        }

        // Event handler for when the 'Delete' button is clicked in the DataGridView
        private void dataGridView_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            // Ensure a valid row is selected
            if (e.RowIndex >= 0)
            {
                // Column Index for Delete button (assuming it's the 3rd column, index 2)
                if (e.ColumnIndex == 0) // 0-based index, 2 means the third column
                {
                    // Retrieve cartSerial or relevant unique identifier for the selected row
                    string cartSerial = dataGridView.Rows[e.RowIndex].Cells["cartSerial"].Value.ToString();

                    // Ask for confirmation before deleting the item
                    var result = MessageBox.Show("Are you sure you want to delete this item?", "Confirmation", MessageBoxButtons.YesNo);
                    if (result == DialogResult.Yes)
                    {
                        // Proceed with deleting the cart item
                        CartController cartController = new CartController();
                        cartController.DeleteCartItem(cartSerial);

                        // Refresh the DataGridView to reflect the deletion
                        Display();  // Re-fetch and display the updated cart data
                    }
                }
            }
        }

        // Display the cart items when the form is shown
        private void CartSummaryForm_Shown(object sender, EventArgs e)
        {
            Display();  // Load the cart items into the DataGridView
        }

        private void CartSummaryForm_Load(object sender, EventArgs e)
        {
        }




        private void buttonConfirm_Click(object sender, EventArgs e)
        {
            try
            {
                // Step 1: Check if the cart is empty
                Cart cart = new Cart();  // Cart class er instance create kora
                List<CartItem> cartItems = cart.GetAllCartItems();  // Get all cart items

                if (cartItems.Count == 0)
                {
                    // Show message if cart is empty
                    MessageBox.Show("Your Cart is empty, please add product to your cart.", "Cart Empty", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;  // Exit the method if cart is empty
                }

                // Step 2: Navigate to PaymentHomeFrame
                PaymentHomeFrame paymentFrame = new PaymentHomeFrame();
                paymentFrame.Show();  // Show the payment frame
                this.Hide();  // Hide the CartSummaryForm

                // Step 3: Update product quantity in the main product table
                ProductController productController = new ProductController();
                foreach (var item in cartItems)
                {
                    // Update the stock quantity in the product table
                    productController.UpdateProductQuantity(item.ProductName, item.Quantity);  // Update quantity in product table
                }

                // Step 4: Clear all items from the cart
                cart.ClearCart();  // Clear the cart

                // Step 5: After clearing the cart, update DataGridView and total amount
                dataGridView.DataSource = null;  // Unbind data source from DataGridView to avoid errors
                dataGridView.Rows.Clear();  // Clear all rows from DataGridView

                // Reset the total amount to 0 after clearing the cart
                textBoxTotalAmount.Text = "0.00";
            }
            catch (ArgumentException argEx)
            {
                // Handle ArgumentException specifically
                MessageBox.Show($"Error: {argEx.Message}", "Argument Exception", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            catch (Exception ex)
            {
                // Handle other exceptions
                MessageBox.Show($"An error occurred: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }












        private void textBoxTotalAmount_TextChanged(object sender, EventArgs e)
        {
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            CustomerHomeFrame cf = new CustomerHomeFrame();
            cf.Show();
        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
