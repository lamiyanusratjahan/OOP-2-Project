﻿using Pharmacy_Management_System.controller;
using Pharmacy_Management_System.model;
using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace Pharmacy_Management_System.view
{
    public partial class CustomerHomeFrame : Form
    {
        public CustomerHomeFrame()
        {
            InitializeComponent();
        }

        // Display all products or filtered products by name
        public void Display(string query = "SELECT productName, category, price, discount, priceAfterDiscount, stockQuantity, expiryDate FROM Product")
        {
            Logins.DisplayAndSearch(query, dataGridView);
        }

        private void CustomerHomeFrame_Shown(object sender, EventArgs e)
        {
            Display(); // Display all products initially
        }

        // Search for a product by name
        private void txtSearch_TextChanged(object sender, EventArgs e)
        {
            string searchQuery = txtSearch.Text.Trim(); // Get the search input

            if (!string.IsNullOrEmpty(searchQuery))
            {
                // Search query to filter products by name
                string query = $"SELECT productName, category, price, discount, priceAfterDiscount, stockQuantity, expiryDate FROM Product WHERE productName LIKE '%{searchQuery}%'";
                Display(query); // Display products matching the search query
            }
            else
            {
                // If the search box is empty, display all products
                Display();
            }
        }

        private void dataGridView_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                // Retrieve the selected row
                DataGridViewRow selectedRow = dataGridView.Rows[e.RowIndex];
                productnametextbox.Text = selectedRow.Cells["productName"].Value.ToString();
                pricetextbox.Text = selectedRow.Cells["priceAfterDiscount"].Value.ToString();
                quantitytextbox.Text = "0";  // Reset quantity
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                // Get the selected product details
                DataGridViewRow selectedRow = dataGridView.CurrentRow;
                string productName = selectedRow.Cells["productName"].Value.ToString();
                int stockQuantity = Convert.ToInt32(selectedRow.Cells["stockQuantity"].Value);

                // Get the entered quantity
                int enteredQuantity = int.Parse(quantitytextbox.Text.Trim());

                // Validate that the quantity does not exceed stock quantity
                if (enteredQuantity <= 0 || enteredQuantity > stockQuantity)
                {
                    MessageBox.Show("Quantity must be greater than 0 and cannot exceed available stock.");
                    return;
                }

                // Create a new CartItem
                CartItem item = new CartItem
                {
                    CartSerial = Guid.NewGuid().ToString(),
                    ProductName = productName,
                    PriceAfterDiscount = float.Parse(pricetextbox.Text.Trim()),
                    Quantity = enteredQuantity
                };
                item.Total = item.PriceAfterDiscount * item.Quantity;

                // Add the item to the cart
                CartController cartController = new CartController();
                cartController.AddCartItem(item);

                MessageBox.Show($"{item.ProductName} added successfully.");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error adding to cart: " + ex.Message);
            }
        }

        private void buttonGoToCart_Click(object sender, EventArgs e)
        {
            // Navigate to Cart Summary Form
            this.Hide();
            CartSummaryForm summaryForm = new CartSummaryForm();
            summaryForm.Show();
        }

        private void CustomerHomeFrame_Load(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {
            this.Hide();
            LoginForm lg = new LoginForm();
            lg.Show();
            
        }

        private void label2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}

