﻿namespace Pharmacy_Management_System.view
{
    partial class PaymentHomeFrame
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(PaymentHomeFrame));
            this.label1 = new System.Windows.Forms.Label();
            this.pictureBoxRocket = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBoxUpay = new System.Windows.Forms.PictureBox();
            this.pictureBoxNagad = new System.Windows.Forms.PictureBox();
            this.pictureBoxCOD = new System.Windows.Forms.PictureBox();
            this.button3 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxRocket)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxUpay)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxNagad)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxCOD)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 20F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(373, 53);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(485, 54);
            this.label1.TabIndex = 0;
            this.label1.Text = "Select a Payment Option";
            // 
            // pictureBoxRocket
            // 
            this.pictureBoxRocket.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxRocket.Image")));
            this.pictureBoxRocket.Location = new System.Drawing.Point(382, 299);
            this.pictureBoxRocket.Name = "pictureBoxRocket";
            this.pictureBoxRocket.Size = new System.Drawing.Size(153, 124);
            this.pictureBoxRocket.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBoxRocket.TabIndex = 1;
            this.pictureBoxRocket.TabStop = false;
            this.pictureBoxRocket.Click += new System.EventHandler(this.pictureBoxRocket_Click);
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox3.Image")));
            this.pictureBox3.Location = new System.Drawing.Point(382, 139);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(153, 124);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox3.TabIndex = 3;
            this.pictureBox3.TabStop = false;
            this.pictureBox3.Click += new System.EventHandler(this.pictureBox3_Click);
            // 
            // pictureBoxUpay
            // 
            this.pictureBoxUpay.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxUpay.Image")));
            this.pictureBoxUpay.Location = new System.Drawing.Point(663, 299);
            this.pictureBoxUpay.Name = "pictureBoxUpay";
            this.pictureBoxUpay.Size = new System.Drawing.Size(153, 124);
            this.pictureBoxUpay.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBoxUpay.TabIndex = 4;
            this.pictureBoxUpay.TabStop = false;
            this.pictureBoxUpay.Click += new System.EventHandler(this.pictureBoxUpay_Click);
            // 
            // pictureBoxNagad
            // 
            this.pictureBoxNagad.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxNagad.Image")));
            this.pictureBoxNagad.Location = new System.Drawing.Point(663, 139);
            this.pictureBoxNagad.Name = "pictureBoxNagad";
            this.pictureBoxNagad.Size = new System.Drawing.Size(153, 124);
            this.pictureBoxNagad.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBoxNagad.TabIndex = 5;
            this.pictureBoxNagad.TabStop = false;
            this.pictureBoxNagad.Click += new System.EventHandler(this.pictureBoxNagad_Click);
            // 
            // pictureBoxCOD
            // 
            this.pictureBoxCOD.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxCOD.Image")));
            this.pictureBoxCOD.Location = new System.Drawing.Point(902, 219);
            this.pictureBoxCOD.Name = "pictureBoxCOD";
            this.pictureBoxCOD.Size = new System.Drawing.Size(153, 124);
            this.pictureBoxCOD.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBoxCOD.TabIndex = 6;
            this.pictureBoxCOD.TabStop = false;
            this.pictureBoxCOD.Click += new System.EventHandler(this.pictureBoxCOD_Click);
            // 
            // button3
            // 
            this.button3.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button3.ForeColor = System.Drawing.Color.Coral;
            this.button3.Location = new System.Drawing.Point(1097, 64);
            this.button3.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(111, 45);
            this.button3.TabIndex = 7;
            this.button3.Text = "Exit";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // PaymentHomeFrame
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.ClientSize = new System.Drawing.Size(1288, 884);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.pictureBoxCOD);
            this.Controls.Add(this.pictureBoxNagad);
            this.Controls.Add(this.pictureBoxUpay);
            this.Controls.Add(this.pictureBox3);
            this.Controls.Add(this.pictureBoxRocket);
            this.Controls.Add(this.label1);
            this.Name = "PaymentHomeFrame";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "PaymentHomeFrame";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxRocket)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxUpay)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxNagad)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxCOD)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pictureBoxRocket;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.PictureBox pictureBoxUpay;
        private System.Windows.Forms.PictureBox pictureBoxNagad;
        private System.Windows.Forms.PictureBox pictureBoxCOD;
        private System.Windows.Forms.Button button3;
    }
}