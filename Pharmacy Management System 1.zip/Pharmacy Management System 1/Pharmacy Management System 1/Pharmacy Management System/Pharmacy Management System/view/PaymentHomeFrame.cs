﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pharmacy_Management_System.view
{
    public partial class PaymentHomeFrame: Form
    {
        public PaymentHomeFrame()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Your payment has been received by Bkash..");
            this.Hide();
            CustomerHomeFrame cf = new CustomerHomeFrame();
            cf.Show();
        }

        private void pictureBoxNagad_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Your payment has been received by Nagad..");
            this.Hide();
            CustomerHomeFrame cf = new CustomerHomeFrame();
            cf.Show();
        }

        private void pictureBoxRocket_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Your payment has been received by Rocket..");
            this.Hide();
            CustomerHomeFrame cf = new CustomerHomeFrame();
            cf.Show();
        }

        private void pictureBoxUpay_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Your payment has been received by Upay..");
            this.Hide();
            CustomerHomeFrame cf = new CustomerHomeFrame();
            cf.Show();
        }

        private void pictureBoxCOD_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Your order has been placed via Cash on Delivery..");
            this.Hide();
            CustomerHomeFrame cf = new CustomerHomeFrame();
            cf.Show();
        }
    }
}
