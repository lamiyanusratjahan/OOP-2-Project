﻿using Pharmacy_Management_System.controller;
using Pharmacy_Management_System.model;
using System;
using System.Text.RegularExpressions;
using System.Windows.Forms;
using System.Drawing;
using System.Data.SqlClient;

namespace Pharmacy_Management_System.view
{
    public partial class RegistrationForm : Form
    {
        public RegistrationForm()
        {
            InitializeComponent();
        }

        private void RegistrationForm_Load(object sender, EventArgs e)
        {
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string userName = textBox2.Text;
            string name = textBox1.Text;
            string password = textBox3.Text;
            string email = textBox4.Text;
            string role = comboBox1.SelectedItem?.ToString();

            try
            {
                // Validate input fields
                if (string.IsNullOrWhiteSpace(name))
                {
                    MessageBox.Show("Please enter the Name.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }
                if (string.IsNullOrWhiteSpace(userName))
                {
                    MessageBox.Show("Please enter the Username.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }
                if (string.IsNullOrWhiteSpace(password))
                {
                    MessageBox.Show("Please enter the Password.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }
                if (string.IsNullOrWhiteSpace(email))
                {
                    MessageBox.Show("Please enter the Email.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                // Validate email format
                if (!Regex.IsMatch(email, @"^[a-zA-Z0-9._%+-]+@gmail\.com$"))
                {
                    MessageBox.Show("Please enter a valid Gmail address (e.g., example@gmail.com).", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                if (string.IsNullOrWhiteSpace(role))
                {
                    MessageBox.Show("Please select a role.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                // Create login object
                Login login = new Login(userName, password, role);
                LoginController lgc = new LoginController();

                try
                {
                    // Try adding login details to the database
                    lgc.AddLogin(login);  // This should add the login details in the database
                }
                catch (SqlException sqlEx)
                {
                    // If there is a primary key violation (duplicate username), show an error message
                    if (sqlEx.Message.Contains("Violation of PRIMARY KEY constraint"))
                    {
                        MessageBox.Show($"Database error adding login: {sqlEx.Message}", "Database Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return; // Stop further operations if the login already exists
                    }
                    else
                    {
                        MessageBox.Show($"Database error occurred: {sqlEx.Message}", "Database Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return;
                    }
                }

                // Add Employee or Customer based on role
                bool isSuccess = false; // Flag to track if adding employee/customer is successful
                if (role == "Employee")
                {
                    Employee c = new Employee(userName, name, password, email, role);
                    EmployeeController cc = new EmployeeController();
                    try
                    {
                        cc.AddEmployee(c); // This should add employee details to the database
                        isSuccess = true;
                    }
                    catch (SqlException sqlEx)
                    {
                        MessageBox.Show($"Database error adding employee: {sqlEx.Message}", "Database Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                else if (role == "Customer")
                {
                    Customer cus = new Customer(userName, name, password, email);
                    CustomerController cc = new CustomerController();
                    try
                    {
                        cc.AddCustomer(cus); // This should add customer details to the database
                        isSuccess = true;
                    }
                    catch (SqlException sqlEx)
                    {
                        MessageBox.Show($"Database error adding customer: {sqlEx.Message}", "Database Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }

                // Show success message ONLY if everything is successful
                if (isSuccess)
                {
                    MessageBox.Show($"{role} Added Successfully", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            catch (Exception ex)
            {
                // General catch for other exceptions
                MessageBox.Show($"An unexpected error occurred: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {
        }

        private void label7_Click(object sender, EventArgs e)
        {
            LoginForm loginForm = new LoginForm();
            loginForm.Show();
            this.Hide();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button1_MouseEnter(object sender, EventArgs e)
        {
            button1.BackColor = Color.FromArgb(41, 128, 185);

            // Optional: Change text color
            button1.ForeColor = Color.White;
        }

        private void button1_MouseLeave(object sender, EventArgs e)
        {
            button1.BackColor = SystemColors.Control;

            // Optional: Restore original text color
            button1.ForeColor = Color.Black;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            LoginForm lf = new LoginForm();
            lf.Show();
            this.Hide();
        }
    }
}

